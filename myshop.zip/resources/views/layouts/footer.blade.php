<footer class="footer pt-4 bg-black w-100">
  <div class="container">
    <div class="row">
      <div class="col-12 col-md text-center text-white">
        <p>+7 (777) 777 - 77 - 77</p>
      </div>
      <div class="col-12 col-md text-center text-white">
        <p>+7 (777) 777 - 77 - 77</p>
      </div>
      <div class="col-12 col-md text-center text-white">
        <a href="mailto:info@wallridestore.kz">info@wallridestore.kz</a>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-12 text-center text-white">
        <p>Все права защищены (с) Wallride store 2020</p>
      </div>
    </div>
  </div>
</footer>
