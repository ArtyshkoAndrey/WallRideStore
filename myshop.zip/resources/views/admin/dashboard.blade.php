@extends('admin.layouts.app')
@section('title', 'Панель администратора')

@section('content')

@endsection
