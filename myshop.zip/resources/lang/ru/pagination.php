<?php

return [
    'previous' => '&laquo; Предыдущий',
    'next' => 'Следующий &raquo;',
];
